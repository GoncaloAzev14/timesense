// How nextjs is going to behave inside the application
/** @type {import('next').NextConfig} */
const nextConfig = {
  poweredByHeader: false,
  output: 'standalone',
};

export default nextConfig;
