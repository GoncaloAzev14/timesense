This file is just so that the pages folder is not empty.

Ignore this file, but do not remove it.
