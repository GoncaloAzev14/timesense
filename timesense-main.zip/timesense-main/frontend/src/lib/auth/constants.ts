//TODO Add this to configuration file
export const EXPIRE_MARGIN_MINUTES = 1;
