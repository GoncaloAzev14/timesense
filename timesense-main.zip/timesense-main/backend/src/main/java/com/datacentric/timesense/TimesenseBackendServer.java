package com.datacentric.timesense;

import java.io.IOException;

import com.datacentric.BackendServer;

// CHECKSTYLE.OFF: HideUtilityClassConstructor
public class TimesenseBackendServer {

    public static void main(String[] args) throws IOException {
        BackendServer.datacentricMain(args);
    }

}
